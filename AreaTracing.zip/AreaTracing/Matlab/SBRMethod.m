clc,clear
Density=32;
load('SimpleScenario.mat')

L=PreData(L);
% Intersect at the endpoints to generate new facets
L = split_segments(L);
% obtain the rectangular boundary
N=size(L,1);
[x_min,x_max,y_min,y_max]=GetRectangularBoundary(L,N);

%% sRayTracing
mapFileName = ('SimpleScenario.stl');
stl=siteviewer("SceneModel",mapFileName);
tx = txsite("cartesian", ...
        "AntennaPosition",[0;0;2], ...
        "TransmitterFrequency",2.4e9,...
         "TransmitterPower",5);
pm = propagationModel("raytracing", ...
        "CoordinateSystem","cartesian", ...
        "Method","sbr", ...
        "AngularSeparation","low", ...
        "MaxNumReflections",2, ...
        "SurfaceMaterial","concrete");
pm.MaxNumDiffractions = 0;
%% Image method
x=linspace(x_min-1,x_max+1,Density);
y=linspace(y_min-1,y_max+1,Density);

Ray_Cir=cell(Density,Density);
for i=1:Density
    for j=1:Density
        %calculate ray cir
        pos=[x(i);y(j);2];
        rx = rxsite("cartesian", ...
    "AntennaPosition",pos);
        rays=raytrace(tx,rx,pm);
        if ~isempty(rays{1,1})
            % cal CIR
            rx_rtChan = comm.RayTracingChannel(rays{1,1},tx,rx);
            rx_rtChan.SampleRate = 300e6;
            rx_rtChan.ReceiverVirtualVelocity = [0; 0; 0];
            rx_rtChan.ChannelFiltering=false;
            rx_CIR=rx_rtChan();
            AbsCIR=abs(rx_CIR);
            rx_cir=AbsCIR(1,:);
            rx_Delay=zeros(1,length(rx_cir));
            for l=1:length(rx_cir)
                rx_Delay(l)=rays{1, 1}(1, l).PropagationDelay;
            end
        else
            rx_cir=[];
            rx_Delay=[];
        end
        %cal NRMSE
        Ray_Cir{i,j}={rx_cir;rx_Delay};

    end
end
close(stl);
